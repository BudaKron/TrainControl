RRLeanV3 Test Ready

Bench-test sketch for Waveshare ESP32-S3-ETH-8DI-8RO.

Current assumptions:
- DI1=S1, DI2=S2, DI3=S3, DI4=S4
- DI6 advances the next expected logic edge
- DI7 toggles STOP/RUN, and clears a latched fault to STOP
- CH7 pixel power, CH8 UV

If relay mapping is wrong on hardware, report exactly which channel energizes incorrectly and that can be remapped in the next build.
