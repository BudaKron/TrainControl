#pragma once
#include <Arduino.h>
#include <Preferences.h>

struct SensorTiming {
  uint16_t seenDebounceMs;
  uint16_t clearDebounceMs;
  uint16_t stopAfterSeenMs;
  uint16_t stopAfterClearMs;
  uint16_t slowAfterSeenMs;
  uint16_t slowAfterClearMs;
};

struct RRConfig {
  char apSsid[33];
  char apPass[65];
  bool staEnabled;
  char staSsid[33];
  char staPass[65];

  SensorTiming s1;
  SensorTiming s2;
  SensorTiming s3;
  SensorTiming s4;

  uint32_t minBetweenSensorsMs;
  uint32_t sensorStuckTimeoutMs;
  uint32_t timeoutToS1Ms;
  uint32_t timeoutToS2Ms;
  uint32_t timeoutToS3Ms;
  uint32_t timeoutToS4Ms;
  uint32_t startMoveTimeoutMs;
  uint32_t faultRestartLockoutMs;

  uint32_t interlockDeadtimeMs;
  uint32_t selectorSettleMs;
  uint32_t polaritySettleMs;
  uint32_t safeApplyTimeoutMs;
  uint32_t turnoutPulseMs;
  uint32_t turnoutInterpulseMs;
  uint32_t stopToRunCooldownMs;

  uint32_t dwellA_ms;
  uint32_t dwellB_ms;
  uint32_t s2CoastCompMs;
  uint32_t s4CoastCompMs;

  uint32_t pixelPowerOnSettleMs;
  uint32_t pixelBlackBeforePowerCutMs;
  uint32_t sweepInMs;
  int16_t  sweepInCurve;
  uint32_t sweepOutMs;
  int16_t  sweepOutCurve;
  uint32_t caveFadeInMs;
  uint32_t caveFadeOutMs;
  uint8_t  caveHoldBrightnessPct;
  uint8_t  uvOffAtSweepInPct;
  uint8_t  uvOnAtSweepOutPct;

  bool stopDisplayEnabled;
  uint32_t stopDisplayPeriodMs;
  uint8_t  stopDisplayLedBrightnessPct;
  bool beaconDisplayFaultOnlyMode;
};

static inline void setSensorDefaults(SensorTiming& t, uint16_t seen=75, uint16_t clear=100, uint16_t stopSeen=0, uint16_t stopClear=100, uint16_t slowSeen=0, uint16_t slowClear=0) {
  t.seenDebounceMs = seen;
  t.clearDebounceMs = clear;
  t.stopAfterSeenMs = stopSeen;
  t.stopAfterClearMs = stopClear;
  t.slowAfterSeenMs = slowSeen;
  t.slowAfterClearMs = slowClear;
}

static inline void loadDefaults(RRConfig& c) {
  strlcpy(c.apSsid, "RRLeanV4", sizeof(c.apSsid));
  strlcpy(c.apPass, "RocksRock", sizeof(c.apPass));
  c.staEnabled = false;
  c.staSsid[0] = 0;
  c.staPass[0] = 0;

  setSensorDefaults(c.s1, 75, 100, 0, 0, 0, 0);
  setSensorDefaults(c.s2, 75, 100, 0, 250, 0, 0);
  setSensorDefaults(c.s3, 75, 100, 0, 0, 0, 0);
  setSensorDefaults(c.s4, 75, 100, 0, 250, 0, 0);

  c.minBetweenSensorsMs = 50;
  c.sensorStuckTimeoutMs = 6000;
  c.timeoutToS1Ms = 4000;
  c.timeoutToS2Ms = 9000;
  c.timeoutToS3Ms = 9000;
  c.timeoutToS4Ms = 9000;
  c.startMoveTimeoutMs = 2500;
  c.faultRestartLockoutMs = 3000;

  c.interlockDeadtimeMs = 150;
  c.selectorSettleMs = 100;
  c.polaritySettleMs = 100;
  c.safeApplyTimeoutMs = 2500;
  c.turnoutPulseMs = 250;
  c.turnoutInterpulseMs = 750;
  c.stopToRunCooldownMs = 250;

  c.dwellA_ms = 2000;
  c.dwellB_ms = 4000;
  c.s2CoastCompMs = 400;
  c.s4CoastCompMs = 400;

  c.pixelPowerOnSettleMs = 60;
  c.pixelBlackBeforePowerCutMs = 80;
  c.sweepInMs = 1400;
  c.sweepInCurve = -20;
  c.sweepOutMs = 1800;
  c.sweepOutCurve = 20;
  c.caveFadeInMs = 1400;
  c.caveFadeOutMs = 1600;
  c.caveHoldBrightnessPct = 75;
  c.uvOffAtSweepInPct = 50;
  c.uvOnAtSweepOutPct = 50;

  c.stopDisplayEnabled = true;
  c.stopDisplayPeriodMs = 10000;
  c.stopDisplayLedBrightnessPct = 75;
  c.beaconDisplayFaultOnlyMode = false;
}

static inline bool saveConfig(Preferences& prefs, const RRConfig& c) {
  prefs.begin("rrleanv4", false);
  size_t n = prefs.putBytes("cfg", &c, sizeof(c));
  prefs.end();
  return n == sizeof(c);
}

static inline bool loadConfig(Preferences& prefs, RRConfig& c) {
  loadDefaults(c);
  prefs.begin("rrleanv4", true);
  size_t n = prefs.getBytesLength("cfg");
  bool ok = false;
  if (n == sizeof(c)) ok = prefs.getBytes("cfg", &c, sizeof(c)) == sizeof(c);
  prefs.end();
  return ok;
}
