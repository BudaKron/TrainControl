#include <Arduino.h>
#include <algorithm>
#include <math.h>
#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <Adafruit_NeoPixel.h>

#include "Config.h"
#include "State.h"
#include "WebUI.h"

// ---------- Board / hardware mapping ----------
static const uint8_t PIN_DI[9] = {0,4,5,6,7,8,9,10,11};
static const uint8_t PIN_STRIP = 21;
static const uint8_t PIN_BEACON = 47;
static const uint8_t I2C_SCL_PIN = 41;
static const uint8_t I2C_SDA_PIN = 42;
static const uint8_t TCA_ADDR = 0x20;
static const uint8_t REG_OUTPUT = 0x01;
static const uint8_t REG_POLARITY = 0x02;
static const uint8_t REG_CONFIG = 0x03;
static const bool DI_ACTIVE_LOW = true;
static const bool DI6_PRESSED_IS_OPEN = false;
static const bool DI7_PRESSED_IS_OPEN = false;
static const uint8_t PIXEL_COUNT = 51; // 0..15 tunnel, 16..50 cave
static const uint8_t BEACON_COUNT = 4;
static const uint8_t PIN_ONBOARD = 38;
static const uint8_t ONBOARD_COUNT = 1;

static const uint16_t DI7_HOLD_MS = 900;
static const uint16_t PIXEL_SEQ_CAP_MS = 150;

WebServer server(80);
Preferences prefs;
RRConfig cfg;
RuntimeState st;
IPAddress apIP(10,10,0,10), apGW(10,10,0,10), apSN(255,255,255,0);
Adafruit_NeoPixel strip(PIXEL_COUNT, PIN_STRIP, NEO_GRB + NEO_KHZ800);
Adafruit_NeoPixel beacon(BEACON_COUNT, PIN_BEACON, NEO_GRB + NEO_KHZ800);
Adafruit_NeoPixel onboard(ONBOARD_COUNT, PIN_ONBOARD, NEO_GRB + NEO_KHZ800);
uint8_t tcaOutputState = 0x00;

bool wifiStaConnected = false;
String wifiStaIp = "-";
String wifiModeName = "AP";

static const char* applyStageName(SafeApplyStage s){ switch(s){ case APPLY_IDLE:return "IDLE"; case APPLY_CUT_POWER:return "CUT_POWER"; case APPLY_SET_SELECTOR:return "SET_SELECTOR"; case APPLY_SET_POLARITY:return "SET_POLARITY"; case APPLY_ENABLE_POWER:return "ENABLE_POWER"; default:return "?"; } }
static void jsonStr(const String& body, const char* key, char* dest, size_t destSize){ String pat = String("\"") + key + "\":\""; int i = body.indexOf(pat); if(i < 0) return; i += pat.length(); int j = body.indexOf('"', i); if(j < 0) return; String v = body.substring(i, j); v.replace("\\", "\\"); v.replace("\"", "\""); strlcpy(dest, v.c_str(), destSize); }

enum ActionKind : uint8_t { ACT_NONE=0, ACT_SLOW, ACT_STOP, ACT_END_DWELL };

static void processSensorEvent(SensorId sensor, bool seenEdge, bool clearEdge);
static void goStoppedA(const char* note);
static void goStoppedB(const char* note);
static void startVisibleRun(const char* note);
static void startHiddenReturn(const char* note);
static void clearFaultToStop();
static void pressRun();
static void pressStop();
static void pressReturn();
static void forceExpectedProgress();
static void refreshNextAdvanceEdge();
static void setMotionFault(const String& code, const char* note);
static void setPowerFault(const String& code, const char* note);
static void tickOnboardIndicator();

// ---------- JSON helpers ----------
static inline uint32_t jsonVal(const String& body, const String& name, uint32_t current){ String key="\""+name+"\""; int idx=body.indexOf(key); if(idx<0) return current; idx=body.indexOf(':',idx); if(idx<0) return current; int s=idx+1; while(s<(int)body.length() && (body[s]==' '||body[s]=='\"')) s++; int e=s; if(body[s]=='-') e++; while(e<(int)body.length() && (isdigit((unsigned char)body[e])||body[e]=='-')) e++; return (uint32_t)body.substring(s,e).toInt(); }
static inline int32_t jsonIVal(const String& body, const String& name, int32_t current){ return (int32_t)jsonVal(body,name,(uint32_t)current); }
static inline bool jsonBool(const String& body, const String& name, bool current){ String key="\""+name+"\""; int idx=body.indexOf(key); if(idx<0) return current; idx=body.indexOf(':',idx); if(idx<0) return current; int s=idx+1; while(s<(int)body.length() && body[s]==' ') s++; if(body.startsWith("true",s)) return true; if(body.startsWith("false",s)) return false; return current; }

static inline void applyJsonToSensor(const String& key, SensorTiming& s, const String& body){
  s.seenDebounceMs   = jsonVal(body, key + "_seenDebounceMs", s.seenDebounceMs);
  s.clearDebounceMs  = jsonVal(body, key + "_clearDebounceMs", s.clearDebounceMs);
  s.stopAfterSeenMs  = jsonVal(body, key + "_stopAfterSeenMs", s.stopAfterSeenMs);
  s.stopAfterClearMs = jsonVal(body, key + "_stopAfterClearMs", s.stopAfterClearMs);
  s.slowAfterSeenMs  = jsonVal(body, key + "_slowAfterSeenMs", s.slowAfterSeenMs);
  s.slowAfterClearMs = jsonVal(body, key + "_slowAfterClearMs", s.slowAfterClearMs);
}

// ---------- Utility ----------
static SensorTiming& timingFor(SensorId s){ switch(s){ case SENSOR_S1:return cfg.s1; case SENSOR_S2:return cfg.s2; case SENSOR_S3:return cfg.s3; default:return cfg.s4; } }
static uint32_t timeoutForExpected(){
  if(st.expectedSensor=="S1") return cfg.timeoutToS1Ms;
  if(st.expectedSensor=="S2") return cfg.timeoutToS2Ms;
  if(st.expectedSensor=="S3") return cfg.timeoutToS3Ms;
  if(st.expectedSensor=="S4") return cfg.timeoutToS4Ms;
  return cfg.timeoutToS2Ms;
}
static void clearPending(PendingAction& p){ p.active=false; p.dueAt=0; p.kind=ACT_NONE; p.sensor=SENSOR_NONE; p.note=""; }
static void setPhase(LoopPhase p, const char* note){ st.phase=p; st.loopState=phaseName(p); st.phaseChangedAt=millis(); if(note) st.phaseNote=note; refreshNextAdvanceEdge(); }
static void setExpected(SensorId s, const char* note){ st.expectedSensor=sensorName(s); st.lastExpectedArmAt=millis(); st.firstProgressSeen=false; if(note) st.phaseNote=note; refreshNextAdvanceEdge(); }
static void setShowState(ShowState s){ st.showState=s; st.showName=showStateName(s); st.showStartedAt=millis(); }
static void setMotionStrings(const char* route, const char* direction, const char* speed){ st.route=route; st.direction=direction; st.speed=speed; }

// ---------- TCA9554 relay driver ----------
static void tcaWriteReg(uint8_t reg, uint8_t value){ Wire.beginTransmission(TCA_ADDR); Wire.write(reg); Wire.write(value); Wire.endTransmission(); }
static void relSetBit(uint8_t ch, bool on){ if(ch<1 || ch>8) return; if(on) tcaOutputState |= (1u<<(ch-1)); else tcaOutputState &= ~(1u<<(ch-1)); }
static void flushRelayOutputs(){ tcaWriteReg(REG_OUTPUT, tcaOutputState); }
static void composeRelaysToHardware(){
  // CH1 HI gate, CH2 LO gate, CH3 speed select, CH4 dir, CH5 turnout pulse, CH6 track select, CH7 pixel rail, CH8 UV
  tcaOutputState = 0;
  relSetBit(1, st.rel.ch1); relSetBit(2, st.rel.ch2); relSetBit(3, st.rel.ch3); relSetBit(4, st.rel.ch4);
  relSetBit(5, st.rel.ch5); relSetBit(6, st.rel.ch6); relSetBit(7, st.rel.ch7); relSetBit(8, st.rel.ch8);
  flushRelayOutputs();
}

// ---------- Pixel helpers ----------
static uint8_t scalePct(uint8_t pct){ return (uint8_t) constrain((int)pct * 255 / 100, 0, 255); }
static float curvedProgress(float x, int16_t curve){
  x = constrain(x, 0.0f, 1.0f);
  int16_t cc = curve; if(cc < -100) cc = -100; if(cc > 100) cc = 100;
  float c = cc / 100.0f;
  if (fabsf(c) < 0.01f) return x;
  if (c < 0) { float p = 1.0f + (-c * 2.0f); return powf(x, p); }
  float p = 1.0f + (c * 2.0f); return 1.0f - powf(1.0f - x, p);
}
static void fillStripBlack(){ for(uint8_t i=0;i<PIXEL_COUNT;i++) strip.setPixelColor(i,0,0,0); }
static void fillTunnelBlack(){ for(uint8_t i=0;i<16;i++) strip.setPixelColor(i,0,0,0); }
static void fillCaveBrightness(uint8_t pct){ uint8_t b=scalePct(pct); for(uint8_t i=16;i<PIXEL_COUNT;i++) strip.setPixelColor(i,b,b,b); }
static void drawSweep(bool forward, float prog){
  fillTunnelBlack();
  prog = constrain(prog,0.0f,1.0f);
  int head = (int) roundf((forward ? prog : (1.0f-prog)) * 15.0f);
  const float levels[4] = {1.0f,0.60f,0.30f,0.10f};
  for(int k=0;k<4;k++){
    int idx = forward ? head-k : head+k;
    if(idx>=0 && idx<16){ uint8_t b=(uint8_t)(255.0f*levels[k]); strip.setPixelColor(idx,b,b,b); }
  }
}
static void showBlackAndMaybeCutRail(){ fillStripBlack(); strip.show(); }
static void requestPixelRailOn(){
  if(!st.rel.ch7){ st.rel.ch7 = true; st.pixelPowerOnReadyAt = millis() + min<uint32_t>(cfg.pixelPowerOnSettleMs, PIXEL_SEQ_CAP_MS); }
}
static void requestPixelRailOff(){
  if(st.rel.ch7){ fillStripBlack(); strip.show(); st.pixelCutAt = millis() + min<uint32_t>(cfg.pixelBlackBeforePowerCutMs, PIXEL_SEQ_CAP_MS); }
  else st.pixelCutAt = 0;
}
static bool pixelRailReady(){ return st.rel.ch7 && millis() >= st.pixelPowerOnReadyAt; }
static void tickPixelRailSequencer(){ if(st.pixelCutAt && millis() >= st.pixelCutAt){ st.rel.ch7 = false; st.pixelCutAt = 0; } }

// ---------- Onboard status LED ----------
static void tickOnboardIndicator(){
  uint32_t color = 0;
  uint32_t now = millis();
  if(st.faultLatched){
    color = ((now/300)%2==0) ? onboard.Color(255,0,0) : 0;
  } else if(st.mode==MODE_RUN){
    color = onboard.Color(0,220,0);
  } else if(st.mode==MODE_RETURN){
    color = onboard.Color(255,180,0);
  } else {
    color = onboard.Color(220,0,0);
  }
  onboard.setPixelColor(0, color);
  onboard.show();
}

// ---------- Beacon ----------
static String beaconModeName(){ return cfg.beaconDisplayFaultOnlyMode ? "FAULT_ONLY" : "NORMAL"; }
static void tickBeacon(){
  uint32_t now = millis();
  uint32_t color=0;
  if(cfg.beaconDisplayFaultOnlyMode){
    if(st.faultLatched && ((now/350)%2==0)) color = beacon.Color(255,0,0);
  } else {
    if(st.faultLatched) color = ((now/350)%2==0) ? beacon.Color(255,0,0) : 0;
    else if(st.mode==MODE_RUN) color = beacon.Color(0,220,0);
    else if(st.mode==MODE_RETURN) color = beacon.Color(255,180,0);
    else color = beacon.Color(220,0,0);
  }
  for(uint8_t i=0;i<BEACON_COUNT;i++) beacon.setPixelColor(i,color);
  beacon.show();
}

// ---------- Show / cave lighting ----------
static void setSafeDarkCave(bool uvOn){
  fillStripBlack(); strip.show();
  requestPixelRailOff();
  st.rel.ch8 = uvOn;
}
static void enterStopDisplay(){ st.stopDisplayPhaseIsLed=false; st.stopDisplayPhaseStartedAt=millis(); setShowState(SHOW_STOP_DISPLAY); }
static void startSweepIn(){ st.arrivalSweepDoneThisCycle=true; setShowState(SHOW_SWEEP_IN); requestPixelRailOn(); }
static void startSweepOut(){ st.departureSweepDoneThisCycle=true; setShowState(SHOW_SWEEP_OUT); requestPixelRailOn(); }

static void tickShow(){
  uint32_t now = millis();
  if(st.faultLatched){
    setShowState(SHOW_FAULT_OVERRIDE);
    if(st.faultCutsCavePower) setSafeDarkCave(false);
    else {
      if(cfg.stopDisplayEnabled){ if(st.showState != SHOW_STOP_DISPLAY) enterStopDisplay(); }
      else setSafeDarkCave(true);
    }
    return;
  }

  if(st.phase==PHASE_STOPPED_A || st.phase==PHASE_STOPPED_B){
    if(cfg.stopDisplayEnabled){
      if(st.showState != SHOW_STOP_DISPLAY) enterStopDisplay();
    } else {
      if(st.showState != SHOW_IDLE_UV){ setShowState(SHOW_IDLE_UV); setSafeDarkCave(true); }
    }
  }

  switch(st.showState){
    case SHOW_IDLE_UV:
      setSafeDarkCave(true);
      break;
    case SHOW_STOP_DISPLAY: {
      uint32_t period = std::max<uint32_t>(1000, cfg.stopDisplayPeriodMs);
      if(now - st.stopDisplayPhaseStartedAt >= period){ st.stopDisplayPhaseIsLed = !st.stopDisplayPhaseIsLed; st.stopDisplayPhaseStartedAt = now; }
      if(st.stopDisplayPhaseIsLed){
        st.rel.ch8 = false; requestPixelRailOn(); fillStripBlack(); fillCaveBrightness(cfg.stopDisplayLedBrightnessPct); if(pixelRailReady()) strip.show();
      } else {
        setSafeDarkCave(true);
      }
    } break;
    case SHOW_SWEEP_IN: {
      requestPixelRailOn();
      float p = curvedProgress((float)(now - st.showStartedAt) / (float)std::max<uint32_t>(1,cfg.sweepInMs), cfg.sweepInCurve);
      fillStripBlack();
      drawSweep(true, p);
      uint8_t cavePct = (uint8_t) constrain((int)roundf((cfg.caveHoldBrightnessPct * std::min(p * ((float)cfg.sweepInMs / std::max<uint32_t>(1,cfg.caveFadeInMs)), 1.0f))), 0, 100);
      fillCaveBrightness(cavePct);
      if((int)(p*100.0f) >= cfg.uvOffAtSweepInPct) st.rel.ch8 = false; else st.rel.ch8 = true;
      if(p >= 0.999f){ fillTunnelBlack(); fillCaveBrightness(cfg.caveHoldBrightnessPct); st.rel.ch8 = false; setShowState(SHOW_DWELL_LIT); }
      if(pixelRailReady()) strip.show();
    } break;
    case SHOW_DWELL_LIT:
      requestPixelRailOn(); st.rel.ch8 = false; fillStripBlack(); fillCaveBrightness(cfg.caveHoldBrightnessPct); if(pixelRailReady()) strip.show();
      break;
    case SHOW_SWEEP_OUT: {
      requestPixelRailOn();
      float p = curvedProgress((float)(now - st.showStartedAt) / (float)std::max<uint32_t>(1,cfg.sweepOutMs), cfg.sweepOutCurve);
      fillStripBlack();
      drawSweep(false, p);
      float fadeFrac = 1.0f - std::min(p * ((float)cfg.sweepOutMs / std::max<uint32_t>(1,cfg.caveFadeOutMs)), 1.0f);
      uint8_t cavePct = (uint8_t) constrain((int)roundf(cfg.caveHoldBrightnessPct * fadeFrac), 0, 100);
      fillCaveBrightness(cavePct);
      if((int)(p*100.0f) >= cfg.uvOnAtSweepOutPct) st.rel.ch8 = true; else st.rel.ch8 = false;
      if(p >= 0.999f){ fillStripBlack(); strip.show(); requestPixelRailOff(); st.rel.ch8 = true; setShowState(SHOW_IDLE_UV); }
      if(pixelRailReady()) strip.show();
    } break;
    case SHOW_FAULT_OVERRIDE:
      setSafeDarkCave(false);
      break;
  }
}

// ---------- Motion / safety ----------
static void emergencyCutPower(bool cutCavePower){
  st.desiredMotion.powerOn = false;
  st.appliedMotion.powerOn = false;
  st.rel.ch1 = false; st.rel.ch2 = false;
  if(cutCavePower){ fillStripBlack(); strip.show(); st.rel.ch7 = false; st.rel.ch8 = false; }
}
static void setFaultCommon(const String& code, const char* note, bool motionStuck){
  st.faultLatched = true; st.faultCode = code; st.mode = MODE_STOP; setPhase(PHASE_FAULT_STOP, note); st.speed = "OFF"; st.faultAt = millis();
  st.faultCutsCavePower = motionStuck && st.inCaveHazardZone;
  clearPending(st.pendingStop); clearPending(st.pendingSlow); clearPending(st.pendingDwell);
  emergencyCutPower(st.faultCutsCavePower);
  if(!st.faultCutsCavePower && cfg.stopDisplayEnabled) enterStopDisplay();
}
static void setMotionFault(const String& code, const char* note){ setFaultCommon(code, note, true); }
static void setPowerFault(const String& code, const char* note){ setFaultCommon(code, note, false); }
static void ensureRelaySafety(){ if(st.rel.ch1 && st.rel.ch2){ st.rel.ch1=false; st.rel.ch2=false; setPowerFault("FAULT_PWR_BOTH","CH1 and CH2 were on together"); } }
static void requestMotion(bool visible, bool reverse, bool hi, bool powerOn, const char* route, const char* dir, const char* speed){
  st.desiredMotion.trackVisible = visible;
  st.desiredMotion.reverse = reverse;
  st.desiredMotion.hi = hi;
  st.desiredMotion.powerOn = powerOn;
  setMotionStrings(route, dir, speed);
}
static void requestTrack(bool visible){ st.turnoutTargetVisible = visible; }

static void beginSafeApply(){
  st.applyStage = APPLY_CUT_POWER;
  st.applyStageStartedAt = millis();
  st.applyDeadlineAt = millis() + cfg.safeApplyTimeoutMs;
}
static bool motionTargetsDiffer(){
  return st.desiredMotion.powerOn != st.appliedMotion.powerOn || st.desiredMotion.hi != st.appliedMotion.hi || st.desiredMotion.reverse != st.appliedMotion.reverse || st.desiredMotion.trackVisible != st.appliedMotion.trackVisible;
}
static void tickSafeApply(){
  uint32_t now = millis();
  if(st.faultLatched){ st.applyStage = APPLY_IDLE; st.rel.ch1=false; st.rel.ch2=false; return; }
  if(st.applyStage == APPLY_IDLE && motionTargetsDiffer()) beginSafeApply();
  if(st.applyStage == APPLY_IDLE) return;
  if(now > st.applyDeadlineAt){ setPowerFault("FAULT_SAFE_APPLY_TIMEOUT","Safe apply timed out"); return; }
  switch(st.applyStage){
    case APPLY_CUT_POWER:
      st.rel.ch1 = false; st.rel.ch2 = false;
      if(now - st.applyStageStartedAt >= cfg.interlockDeadtimeMs){ st.applyStage = APPLY_SET_SELECTOR; st.applyStageStartedAt = now; }
      break;
    case APPLY_SET_SELECTOR:
      st.rel.ch3 = st.desiredMotion.hi;
      if(now - st.applyStageStartedAt >= cfg.selectorSettleMs){ st.applyStage = APPLY_SET_POLARITY; st.applyStageStartedAt = now; }
      break;
    case APPLY_SET_POLARITY:
      st.rel.ch4 = st.desiredMotion.reverse;
      if(now - st.applyStageStartedAt >= cfg.polaritySettleMs){ st.applyStage = APPLY_ENABLE_POWER; st.applyStageStartedAt = now; }
      break;
    case APPLY_ENABLE_POWER:
      st.rel.ch1 = st.desiredMotion.powerOn && st.desiredMotion.hi;
      st.rel.ch2 = st.desiredMotion.powerOn && !st.desiredMotion.hi;
      st.appliedMotion = st.desiredMotion;
      st.applyStage = APPLY_IDLE;
      break;
    default: break;
  }
}

static void tickTurnout(){
  uint32_t now = millis();
  st.rel.ch6 = !st.turnoutTargetVisible; // false visible, true hidden
  if(st.turnoutPulseActive && now >= st.turnoutPulseUntil){ st.turnoutPulseActive = false; st.rel.ch5 = false; }
  bool needPulse = (st.appliedMotion.trackVisible != st.turnoutTargetVisible);
  if(needPulse && !st.turnoutPulseActive && (now - st.lastTurnoutPulseAt) >= cfg.turnoutInterpulseMs){
    st.turnoutPulseActive = true; st.turnoutPulseUntil = now + cfg.turnoutPulseMs; st.lastTurnoutPulseAt = now; st.rel.ch5 = true; st.appliedMotion.trackVisible = st.turnoutTargetVisible;
  }
}

static void forceExpectedProgress(){
  if(st.faultLatched) return;
  SensorId last = SENSOR_NONE;
  if(st.lastSensor == "S1") last = SENSOR_S1; else if(st.lastSensor == "S2") last = SENSOR_S2; else if(st.lastSensor == "S3") last = SENSOR_S3; else if(st.lastSensor == "S4") last = SENSOR_S4;
  if(st.awaitingClearForLastSeen && last != SENSOR_NONE){ processSensorEvent(last, false, true); return; }
  if(st.pendingSlow.active){ st.pendingSlow.dueAt = millis(); return; }
  if(st.pendingStop.active){ st.pendingStop.dueAt = millis(); return; }
  if(st.pendingDwell.active){ st.pendingDwell.dueAt = millis(); return; }
  if(st.phase==PHASE_DWELL_B){ clearPending(st.pendingDwell); if(!st.manualStop){ startHiddenReturn("DI6 forced dwell-B end"); if(!st.departureSweepDoneThisCycle) startSweepOut(); } else goStoppedB("DI6 at B stop"); return; }
  if(st.phase==PHASE_DWELL_A){ clearPending(st.pendingDwell); if(!st.manualStop){ startVisibleRun("DI6 forced dwell-A end"); } else goStoppedA("DI6 at A stop"); return; }
  if(st.expectedSensor == "S1") processSensorEvent(SENSOR_S1, true, false);
  else if(st.expectedSensor == "S2") processSensorEvent(SENSOR_S2, true, false);
  else if(st.expectedSensor == "S3") processSensorEvent(SENSOR_S3, true, false);
  else if(st.expectedSensor == "S4") processSensorEvent(SENSOR_S4, true, false);
}
static void refreshNextAdvanceEdge(){
  if(st.phase==PHASE_DWELL_B) st.nextAdvanceEdge = "DWELL_B END";
  else if(st.phase==PHASE_DWELL_A) st.nextAdvanceEdge = "DWELL_A END";
  else if(st.awaitingClearForLastSeen && st.lastSensor != "-") st.nextAdvanceEdge = st.lastSensor + String(" CLEAR");
  else if(st.phase==PHASE_VISIBLE_TO_B_POST_S2_SEEN) st.nextAdvanceEdge = "WAIT B STOP";
  else if(st.phase==PHASE_HIDDEN_TO_A_APPROACH_A && st.lastSensor == "S4") st.nextAdvanceEdge = "WAIT A STOP";
  else st.nextAdvanceEdge = st.expectedSensor + String(" SEEN");
}

static void goStoppedA(const char* note){
  st.mode = MODE_STOP; st.manualStop = true; setPhase(PHASE_STOPPED_A,note); requestMotion(true,false,false,false,"VISIBLE","FWD","OFF"); requestTrack(true); setExpected(SENSOR_S1,note); st.arrivalSweepDoneThisCycle=false; st.departureSweepDoneThisCycle=false;
}
static void goStoppedB(const char* note){
  st.mode = MODE_STOP; st.manualStop = true; setPhase(PHASE_STOPPED_B,note); requestMotion(true,false,false,false,"VISIBLE","FWD","OFF"); requestTrack(false); setExpected(SENSOR_S3,note);
}
static void startVisibleRun(const char* note){
  st.mode = MODE_RUN; st.manualStop=false; setPhase(PHASE_VISIBLE_TO_B_PRE_S1,note); requestTrack(true); requestMotion(true,false,false,true,"VISIBLE","FWD","LO"); setExpected(SENSOR_S1,note); st.arrivalSweepDoneThisCycle=false; st.departureSweepDoneThisCycle=false;
}
static void startHiddenReturn(const char* note){
  st.mode = MODE_RETURN; st.manualStop=false; setPhase(PHASE_HIDDEN_TO_A_PRE_S3,note); requestTrack(false); requestMotion(false,true,false,true,"HIDDEN","REV","LO"); setExpected(SENSOR_S3,note);
}

static void scheduleAction(PendingAction& p, uint8_t kind, SensorId sensor, uint32_t delayMs, const char* note){ p.active=true; p.kind=kind; p.sensor=sensor; p.note=note; p.dueAt=millis()+delayMs; }
static void maybeScheduleSensorActions(SensorId sensor, bool seenEdge, bool clearEdge){
  SensorTiming& t = timingFor(sensor);
  if(seenEdge){ if(t.slowAfterSeenMs>0) scheduleAction(st.pendingSlow,ACT_SLOW,sensor,t.slowAfterSeenMs,"slow-after-seen"); if(t.stopAfterSeenMs>0) scheduleAction(st.pendingStop,ACT_STOP,sensor,t.stopAfterSeenMs,"stop-after-seen"); }
  if(clearEdge){ if(t.slowAfterClearMs>0) scheduleAction(st.pendingSlow,ACT_SLOW,sensor,t.slowAfterClearMs,"slow-after-clear"); if(t.stopAfterClearMs>0) scheduleAction(st.pendingStop,ACT_STOP,sensor,t.stopAfterClearMs,"stop-after-clear"); }
}

static void handleExpectedSensorSeen(SensorId sensor){
  st.lastSensor = sensorName(sensor); st.lastSensorEdgeAt = millis(); st.firstProgressSeen = true; st.awaitingClearForLastSeen = true; refreshNextAdvanceEdge();
  st.awaitingClearForLastSeen = false; refreshNextAdvanceEdge();
  switch(sensor){
    case SENSOR_S1: st.seenCountS1++; if(st.phase==PHASE_VISIBLE_TO_B_PRE_S1){ setPhase(PHASE_VISIBLE_TO_B_POST_S1,"S1 seen, continue visible leg"); setExpected(SENSOR_S2,"Expect S2 next"); } break;
    case SENSOR_S2: st.seenCountS2++; st.inCaveHazardZone = true; if(!st.arrivalSweepDoneThisCycle) startSweepIn(); if(st.phase==PHASE_VISIBLE_TO_B_POST_S1 || st.phase==PHASE_VISIBLE_TO_B_PRE_S1){ setPhase(PHASE_VISIBLE_TO_B_POST_S2_SEEN,"S2 seen, approach cave stop"); } break;
    case SENSOR_S3: st.seenCountS3++; if(st.phase==PHASE_HIDDEN_TO_A_PRE_S3){ setPhase(PHASE_HIDDEN_TO_A_POST_S3_SEEN,"S3 seen, wait clear then go HI"); setExpected(SENSOR_S4,"Expect S4 next"); } break;
    case SENSOR_S4: st.seenCountS4++; if(st.phase==PHASE_HIDDEN_TO_A_FAST || st.phase==PHASE_HIDDEN_TO_A_POST_S3_SEEN || st.phase==PHASE_HIDDEN_TO_A_PRE_S3){ setPhase(PHASE_HIDDEN_TO_A_APPROACH_A,"S4 seen, slow for A approach"); requestMotion(false,true,false,true,"HIDDEN","REV","LO"); } break;
    default: break;
  }
}
static void handleExpectedSensorClear(SensorId sensor){
  switch(sensor){
    case SENSOR_S2: if(st.phase==PHASE_VISIBLE_TO_B_POST_S2_SEEN){ scheduleAction(st.pendingStop,ACT_STOP,SENSOR_S2,timingFor(SENSOR_S2).stopAfterClearMs + cfg.s2CoastCompMs,"S2 clear stop at B"); } break;
    case SENSOR_S3: if(st.phase==PHASE_HIDDEN_TO_A_POST_S3_SEEN){ setPhase(PHASE_HIDDEN_TO_A_FAST,"S3 clear, hidden HI"); requestMotion(false,true,true,true,"HIDDEN","REV","HI"); st.inCaveHazardZone = false; } break;
    case SENSOR_S4: if(st.phase==PHASE_HIDDEN_TO_A_APPROACH_A || st.phase==PHASE_HIDDEN_TO_A_FAST){ scheduleAction(st.pendingStop,ACT_STOP,SENSOR_S4,timingFor(SENSOR_S4).stopAfterClearMs + cfg.s4CoastCompMs,"S4 clear stop at A"); } break;
    default: break;
  }
}

static void processSensorEvent(SensorId sensor, bool seenEdge, bool clearEdge){
  if(st.faultLatched) return;
  uint32_t now = millis();
  if(seenEdge && st.lastSensorEdgeAt > 0 && (now - st.lastSensorEdgeAt) < cfg.minBetweenSensorsMs){ setMotionFault("FAULT_MIN_BETWEEN","Sensor edge arrived too soon"); return; }
  if(seenEdge){
    if(st.expectedSensor != sensorName(sensor)){
      // unattended bias: fault wrong path in cave, warn elsewhere
      if(st.inCaveHazardZone || sensor == SENSOR_S2 || sensor == SENSOR_S3) setMotionFault(String("FAULT_UNEXPECTED_") + sensorName(sensor), "Unexpected sensor in critical zone");
      else { st.lastSensor = sensorName(sensor); st.faultCode = String("WARN_UNEXPECTED_") + sensorName(sensor); st.phaseNote = "Unexpected sensor, continuing"; }
    } else handleExpectedSensorSeen(sensor);
  }
  if(!st.faultLatched && clearEdge){ if(st.expectedSensor == sensorName(sensor) || sensor==SENSOR_S2 || sensor==SENSOR_S3 || sensor==SENSOR_S4) handleExpectedSensorClear(sensor); }
  if(!st.faultLatched) maybeScheduleSensorActions(sensor, seenEdge, clearEdge);
}

static void updateDebounced(DebouncedInput& d, bool rawNow, uint16_t seenDebounce, uint16_t clearDebounce){
  uint32_t now = millis(); d.seenEdge=false; d.clearEdge=false;
  if(rawNow != d.raw){ d.raw = rawNow; d.rawChangedAt = now; }
  uint32_t debounceMs = d.raw ? seenDebounce : clearDebounce;
  if(d.raw != d.stable && (now - d.rawChangedAt) >= debounceMs){ d.stable=d.raw; d.stableChangedAt=now; if(d.stable){ d.seenEdge=true; d.activeSince=now; } else { d.clearEdge=true; d.activeSince=0; } }
}
static bool readInputPin(uint8_t pin, bool activeLow){ int v=digitalRead(pin); return activeLow ? (v==LOW) : (v==HIGH); }
static void updateInputs(){
  if(st.useVirtualInputs){ st.in.s1=st.virtualS1; st.in.s2=st.virtualS2; st.in.s3=st.virtualS3; st.in.s4=st.virtualS4; st.in.di6=st.virtualDI6; st.in.di7=st.virtualDI7; }
  else { st.in.s1=readInputPin(PIN_DI[1],DI_ACTIVE_LOW); st.in.s2=readInputPin(PIN_DI[2],DI_ACTIVE_LOW); st.in.s3=readInputPin(PIN_DI[3],DI_ACTIVE_LOW); st.in.s4=readInputPin(PIN_DI[4],DI_ACTIVE_LOW); st.in.di6=readInputPin(PIN_DI[6], !DI6_PRESSED_IS_OPEN); st.in.di7=readInputPin(PIN_DI[7], !DI7_PRESSED_IS_OPEN); }
  updateDebounced(st.dbS1, st.in.s1, cfg.s1.seenDebounceMs, cfg.s1.clearDebounceMs);
  updateDebounced(st.dbS2, st.in.s2, cfg.s2.seenDebounceMs, cfg.s2.clearDebounceMs);
  updateDebounced(st.dbS3, st.in.s3, cfg.s3.seenDebounceMs, cfg.s3.clearDebounceMs);
  updateDebounced(st.dbS4, st.in.s4, cfg.s4.seenDebounceMs, cfg.s4.clearDebounceMs);
  updateDebounced(st.dbDI6, st.in.di6, 50, 50);
  updateDebounced(st.dbDI7, st.in.di7, 50, 50);
  if(st.dbS1.seenEdge || st.dbS1.clearEdge) processSensorEvent(SENSOR_S1, st.dbS1.seenEdge, st.dbS1.clearEdge);
  if(st.dbS2.seenEdge || st.dbS2.clearEdge) processSensorEvent(SENSOR_S2, st.dbS2.seenEdge, st.dbS2.clearEdge);
  if(st.dbS3.seenEdge || st.dbS3.clearEdge) processSensorEvent(SENSOR_S3, st.dbS3.seenEdge, st.dbS3.clearEdge);
  if(st.dbS4.seenEdge || st.dbS4.clearEdge) processSensorEvent(SENSOR_S4, st.dbS4.seenEdge, st.dbS4.clearEdge);
  if(st.dbDI6.seenEdge) forceExpectedProgress();
  if(st.dbDI7.seenEdge){ st.di7PressedAt = millis(); st.di7HoldHandled = false; }
  if(st.dbDI7.stable && !st.di7HoldHandled && (millis() - st.di7PressedAt) >= DI7_HOLD_MS){
    st.di7HoldHandled = true;
    if(st.faultLatched) clearFaultToStop();
    else if(st.mode==MODE_RUN) pressReturn();
    else if(st.mode==MODE_STOP) pressRun();
    else pressReturn();
  }
  if(st.dbDI7.clearEdge){
    if(!st.di7HoldHandled){
      if(st.faultLatched) clearFaultToStop();
      else if(st.mode==MODE_RUN) pressStop();
      else if(st.mode==MODE_STOP) pressReturn();
      else pressStop();
    }
    st.di7HoldHandled = false;
  }
}


static void handleAction(PendingAction& p){
  if(!p.active || millis() < p.dueAt || st.faultLatched) return;
  switch(p.kind){
    case ACT_SLOW:
      if(p.sensor == SENSOR_S4) requestMotion(false,true,false,true,"HIDDEN","REV","LO");
      else requestMotion(true,false,false,true,"VISIBLE","FWD","LO");
      break;
    case ACT_STOP:
      if(p.sensor == SENSOR_S2){
        requestMotion(true,false,false,false,"VISIBLE","FWD","OFF");
        setPhase(PHASE_DWELL_B,"Stopped at B dwell");
        setExpected(SENSOR_S3,"Expect S3 after departure");
        setShowState(SHOW_DWELL_LIT);
        scheduleAction(st.pendingDwell, ACT_END_DWELL, SENSOR_S2, cfg.dwellB_ms, "End dwell B"); refreshNextAdvanceEdge();
      } else if(p.sensor == SENSOR_S4){
        requestMotion(false,true,false,false,"HIDDEN","REV","OFF");
        setPhase(PHASE_DWELL_A,"Stopped at A dwell");
        setExpected(SENSOR_S1,"Expect S1 after departure");
        scheduleAction(st.pendingDwell, ACT_END_DWELL, SENSOR_S4, cfg.dwellA_ms, "End dwell A"); refreshNextAdvanceEdge();
      }
      break;
    case ACT_END_DWELL:
      if(st.phase == PHASE_DWELL_B && !st.manualStop){ startHiddenReturn("Dwell B done"); if(!st.departureSweepDoneThisCycle) startSweepOut(); }
      else if(st.phase == PHASE_DWELL_A && !st.manualStop){ startVisibleRun("Dwell A done"); }
      else if(st.phase == PHASE_DWELL_B) goStoppedB("Manual stop at B");
      else if(st.phase == PHASE_DWELL_A) goStoppedA("Manual stop at A");
      break;
  }
  clearPending(p); refreshNextAdvanceEdge();
}
static void tickPending(){ handleAction(st.pendingSlow); handleAction(st.pendingStop); handleAction(st.pendingDwell); }

static void tickFaults(){
  uint32_t now = millis();
  if(st.faultLatched) return;
  if(st.speed != "OFF"){
    if(!st.firstProgressSeen && st.lastExpectedArmAt > 0 && (now - st.lastExpectedArmAt) > cfg.startMoveTimeoutMs){ setMotionFault("FAULT_NO_START_PROGRESS","No initial progress after move command"); return; }
    uint32_t tmo = timeoutForExpected();
    if(st.lastExpectedArmAt > 0 && (now - st.lastExpectedArmAt) > tmo){ setMotionFault("FAULT_EXPECT_TIMEOUT","Expected sensor timeout"); return; }
  }
  auto checkStuck=[&](DebouncedInput& d,const char* name){ if(d.stable && d.activeSince > 0 && (now - d.activeSince) > cfg.sensorStuckTimeoutMs) setMotionFault(String("FAULT_STUCK_")+name, "Sensor stayed active too long"); };
  checkStuck(st.dbS1,"S1"); if(!st.faultLatched) checkStuck(st.dbS2,"S2"); if(!st.faultLatched) checkStuck(st.dbS3,"S3"); if(!st.faultLatched) checkStuck(st.dbS4,"S4");
}

// ---------- Commands ----------
static void clearFaultToStop(){ if(st.faultLatched && (millis() - st.faultAt) < cfg.faultRestartLockoutMs) return; st.faultLatched=false; st.faultCutsCavePower=false; st.faultCode="CLEAR"; st.inCaveHazardZone=false; st.awaitingClearForLastSeen=false; goStoppedA("Fault cleared to STOP"); setShowState(SHOW_IDLE_UV); }
static void pressRun(){ if((millis() - st.modeChangedAt) < cfg.stopToRunCooldownMs) return; st.modeChangedAt=millis(); st.faultLatched=false; st.faultCutsCavePower=false; st.faultCode="CLEAR"; st.awaitingClearForLastSeen=false; startVisibleRun("RUN command"); }
static void pressStop(){ st.modeChangedAt=millis(); st.manualStop=true; st.awaitingClearForLastSeen=false; if(st.phase==PHASE_DWELL_B || st.phase==PHASE_STOPPED_B) goStoppedB("STOP command"); else goStoppedA("STOP command"); }
static void pressReturn(){ if((millis() - st.modeChangedAt) < cfg.stopToRunCooldownMs) return; st.modeChangedAt=millis(); st.faultLatched=false; st.faultCutsCavePower=false; st.faultCode="CLEAR"; st.awaitingClearForLastSeen=false; startHiddenReturn("RETURN command"); }

// ---------- HTTP ----------
void handleIndex(){ server.send_P(200,"text/html",HTML_INDEX); }
void handleState(){
  String out="{";
  out += "\"ip\":\"" + WiFi.softAPIP().toString() + "\",";
  out += "\"apIp\":\"" + WiFi.softAPIP().toString() + "\",";
  out += "\"staIp\":\"" + wifiStaIp + "\",";
  out += "\"wifiMode\":\"" + wifiModeName + "\",";
  out += "\"mode\":\"" + String(modeStr(st.mode)) + "\",";
  out += "\"faultLatched\":" + String(st.faultLatched?"true":"false") + ",";
  out += "\"faultCode\":\"" + st.faultCode + "\",";
  out += "\"expectedSensor\":\"" + st.expectedSensor + "\",";
  out += "\"lastSensor\":\"" + st.lastSensor + "\",";
  out += "\"route\":\"" + st.route + "\",";
  out += "\"direction\":\"" + st.direction + "\",";
  out += "\"speed\":\"" + st.speed + "\",";
  out += "\"loopState\":\"" + st.loopState + "\",";
  out += "\"phaseNote\":\"" + st.phaseNote + "\",";
  out += "\"showName\":\"" + st.showName + "\",";
  out += "\"applyStage\":" + String((int)st.applyStage) + ",";
  out += "\"applyStageText\":\"" + String(applyStageName(st.applyStage)) + "\",";
  out += "\"beaconMode\":\"" + beaconModeName() + "\",";
  out += "\"nextAdvanceEdge\":\"" + st.nextAdvanceEdge + "\",";
  out += "\"inCaveHazardZone\":" + String(st.inCaveHazardZone?"true":"false") + ",";
  out += "\"counters\":{\"s1\":" + String(st.seenCountS1) + ",\"s2\":" + String(st.seenCountS2) + ",\"s3\":" + String(st.seenCountS3) + ",\"s4\":" + String(st.seenCountS4) + "},";
  out += "\"inputs\":{\"s1\":" + String(st.in.s1?"true":"false") + ",\"s2\":" + String(st.in.s2?"true":"false") + ",\"s3\":" + String(st.in.s3?"true":"false") + ",\"s4\":" + String(st.in.s4?"true":"false") + ",\"di6\":" + String(st.in.di6?"true":"false") + ",\"di7\":" + String(st.in.di7?"true":"false") + "},";
  out += "\"relays\":{\"ch1\":" + String(st.rel.ch1?"true":"false") + ",\"ch2\":" + String(st.rel.ch2?"true":"false") + ",\"ch3\":" + String(st.rel.ch3?"true":"false") + ",\"ch4\":" + String(st.rel.ch4?"true":"false") + ",\"ch5\":" + String(st.rel.ch5?"true":"false") + ",\"ch6\":" + String(st.rel.ch6?"true":"false") + ",\"ch7\":" + String(st.rel.ch7?"true":"false") + ",\"ch8\":" + String(st.rel.ch8?"true":"false") + "}";
  out += "}";
  server.send(200,"application/json",out);
}
void handleCmd(){ String m=server.arg("mode"); if(m=="run") pressRun(); else if(m=="stop") pressStop(); else if(m=="return") pressReturn(); else if(m=="clearfault") clearFaultToStop(); else if(m=="advance") forceExpectedProgress(); server.send(200,"application/json","{\"ok\":true}"); }
void handleInject(){ String body=server.arg("plain"); st.useVirtualInputs=true; st.virtualS1=jsonBool(body,"s1",st.virtualS1); st.virtualS2=jsonBool(body,"s2",st.virtualS2); st.virtualS3=jsonBool(body,"s3",st.virtualS3); st.virtualS4=jsonBool(body,"s4",st.virtualS4); st.virtualDI6=jsonBool(body,"di6",st.virtualDI6); st.virtualDI7=jsonBool(body,"di7",st.virtualDI7); server.send(200,"application/json","{\"ok\":true}"); }
void handleSetupGet(){
  String out="{"; auto add=[&](const char* n, int32_t v){ out += "\""; out += n; out += "\":"; out += String(v); out += ",";}; auto addb=[&](const char* n, bool v){ out += "\""; out += n; out += "\":"; out += (v?"true":"false"); out += ",";};
  add("s1_seenDebounceMs",cfg.s1.seenDebounceMs); add("s1_clearDebounceMs",cfg.s1.clearDebounceMs); add("s1_stopAfterSeenMs",cfg.s1.stopAfterSeenMs); add("s1_stopAfterClearMs",cfg.s1.stopAfterClearMs); add("s1_slowAfterSeenMs",cfg.s1.slowAfterSeenMs); add("s1_slowAfterClearMs",cfg.s1.slowAfterClearMs);
  add("s2_seenDebounceMs",cfg.s2.seenDebounceMs); add("s2_clearDebounceMs",cfg.s2.clearDebounceMs); add("s2_stopAfterSeenMs",cfg.s2.stopAfterSeenMs); add("s2_stopAfterClearMs",cfg.s2.stopAfterClearMs); add("s2_slowAfterSeenMs",cfg.s2.slowAfterSeenMs); add("s2_slowAfterClearMs",cfg.s2.slowAfterClearMs);
  add("s3_seenDebounceMs",cfg.s3.seenDebounceMs); add("s3_clearDebounceMs",cfg.s3.clearDebounceMs); add("s3_stopAfterSeenMs",cfg.s3.stopAfterSeenMs); add("s3_stopAfterClearMs",cfg.s3.stopAfterClearMs); add("s3_slowAfterSeenMs",cfg.s3.slowAfterSeenMs); add("s3_slowAfterClearMs",cfg.s3.slowAfterClearMs);
  add("s4_seenDebounceMs",cfg.s4.seenDebounceMs); add("s4_clearDebounceMs",cfg.s4.clearDebounceMs); add("s4_stopAfterSeenMs",cfg.s4.stopAfterSeenMs); add("s4_stopAfterClearMs",cfg.s4.stopAfterClearMs); add("s4_slowAfterSeenMs",cfg.s4.slowAfterSeenMs); add("s4_slowAfterClearMs",cfg.s4.slowAfterClearMs);
  add("minBetweenSensorsMs",cfg.minBetweenSensorsMs); add("sensorStuckTimeoutMs",cfg.sensorStuckTimeoutMs); add("timeoutToS1Ms",cfg.timeoutToS1Ms); add("timeoutToS2Ms",cfg.timeoutToS2Ms); add("timeoutToS3Ms",cfg.timeoutToS3Ms); add("timeoutToS4Ms",cfg.timeoutToS4Ms); add("startMoveTimeoutMs",cfg.startMoveTimeoutMs); add("faultRestartLockoutMs",cfg.faultRestartLockoutMs);
  add("interlockDeadtimeMs",cfg.interlockDeadtimeMs); add("selectorSettleMs",cfg.selectorSettleMs); add("polaritySettleMs",cfg.polaritySettleMs); add("safeApplyTimeoutMs",cfg.safeApplyTimeoutMs); add("turnoutPulseMs",cfg.turnoutPulseMs); add("turnoutInterpulseMs",cfg.turnoutInterpulseMs); add("stopToRunCooldownMs",cfg.stopToRunCooldownMs);
  add("dwellA_ms",cfg.dwellA_ms); add("dwellB_ms",cfg.dwellB_ms); add("s2CoastCompMs",cfg.s2CoastCompMs); add("s4CoastCompMs",cfg.s4CoastCompMs);
  add("pixelPowerOnSettleMs",cfg.pixelPowerOnSettleMs); add("pixelBlackBeforePowerCutMs",cfg.pixelBlackBeforePowerCutMs); add("sweepInMs",cfg.sweepInMs); add("sweepInCurve",cfg.sweepInCurve); add("sweepOutMs",cfg.sweepOutMs); add("sweepOutCurve",cfg.sweepOutCurve); add("caveFadeInMs",cfg.caveFadeInMs); add("caveFadeOutMs",cfg.caveFadeOutMs); add("caveHoldBrightnessPct",cfg.caveHoldBrightnessPct); add("uvOffAtSweepInPct",cfg.uvOffAtSweepInPct); add("uvOnAtSweepOutPct",cfg.uvOnAtSweepOutPct);
  addb("stopDisplayEnabled",cfg.stopDisplayEnabled); add("stopDisplayPeriodMs",cfg.stopDisplayPeriodMs); add("stopDisplayLedBrightnessPct",cfg.stopDisplayLedBrightnessPct); addb("beaconDisplayFaultOnlyMode",cfg.beaconDisplayFaultOnlyMode);
  addb("staEnabled",cfg.staEnabled);
  out += "\"apSsid\":\"" + String(cfg.apSsid) + "\",";
  out += "\"apPass\":\"" + String(cfg.apPass) + "\",";
  out += "\"staSsid\":\"" + String(cfg.staSsid) + "\",";
  out += "\"staPass\":\"" + String(cfg.staPass) + "\",";
  if(out.endsWith(",")) out.remove(out.length()-1); out += "}"; server.send(200,"application/json",out);
}
void handleSetupSet(){
  String body=server.arg("plain");
  applyJsonToSensor("s1", cfg.s1, body); applyJsonToSensor("s2", cfg.s2, body); applyJsonToSensor("s3", cfg.s3, body); applyJsonToSensor("s4", cfg.s4, body);
  cfg.minBetweenSensorsMs = jsonVal(body,"minBetweenSensorsMs",cfg.minBetweenSensorsMs); cfg.sensorStuckTimeoutMs = jsonVal(body,"sensorStuckTimeoutMs",cfg.sensorStuckTimeoutMs); cfg.timeoutToS1Ms = jsonVal(body,"timeoutToS1Ms",cfg.timeoutToS1Ms); cfg.timeoutToS2Ms = jsonVal(body,"timeoutToS2Ms",cfg.timeoutToS2Ms); cfg.timeoutToS3Ms = jsonVal(body,"timeoutToS3Ms",cfg.timeoutToS3Ms); cfg.timeoutToS4Ms = jsonVal(body,"timeoutToS4Ms",cfg.timeoutToS4Ms); cfg.startMoveTimeoutMs = jsonVal(body,"startMoveTimeoutMs",cfg.startMoveTimeoutMs); cfg.faultRestartLockoutMs = jsonVal(body,"faultRestartLockoutMs",cfg.faultRestartLockoutMs);
  cfg.interlockDeadtimeMs = jsonVal(body,"interlockDeadtimeMs",cfg.interlockDeadtimeMs); cfg.selectorSettleMs = jsonVal(body,"selectorSettleMs",cfg.selectorSettleMs); cfg.polaritySettleMs = jsonVal(body,"polaritySettleMs",cfg.polaritySettleMs); cfg.safeApplyTimeoutMs = jsonVal(body,"safeApplyTimeoutMs",cfg.safeApplyTimeoutMs); cfg.turnoutPulseMs = jsonVal(body,"turnoutPulseMs",cfg.turnoutPulseMs); cfg.turnoutInterpulseMs = jsonVal(body,"turnoutInterpulseMs",cfg.turnoutInterpulseMs); cfg.stopToRunCooldownMs = jsonVal(body,"stopToRunCooldownMs",cfg.stopToRunCooldownMs);
  cfg.dwellA_ms = jsonVal(body,"dwellA_ms",cfg.dwellA_ms); cfg.dwellB_ms = jsonVal(body,"dwellB_ms",cfg.dwellB_ms); cfg.s2CoastCompMs = jsonVal(body,"s2CoastCompMs",cfg.s2CoastCompMs); cfg.s4CoastCompMs = jsonVal(body,"s4CoastCompMs",cfg.s4CoastCompMs);
  cfg.pixelPowerOnSettleMs = jsonVal(body,"pixelPowerOnSettleMs",cfg.pixelPowerOnSettleMs); cfg.pixelBlackBeforePowerCutMs = jsonVal(body,"pixelBlackBeforePowerCutMs",cfg.pixelBlackBeforePowerCutMs); cfg.sweepInMs = jsonVal(body,"sweepInMs",cfg.sweepInMs); cfg.sweepInCurve = (int16_t)jsonIVal(body,"sweepInCurve",cfg.sweepInCurve); cfg.sweepOutMs = jsonVal(body,"sweepOutMs",cfg.sweepOutMs); cfg.sweepOutCurve = (int16_t)jsonIVal(body,"sweepOutCurve",cfg.sweepOutCurve); cfg.caveFadeInMs = jsonVal(body,"caveFadeInMs",cfg.caveFadeInMs); cfg.caveFadeOutMs = jsonVal(body,"caveFadeOutMs",cfg.caveFadeOutMs); cfg.caveHoldBrightnessPct = (uint8_t)jsonVal(body,"caveHoldBrightnessPct",cfg.caveHoldBrightnessPct); cfg.uvOffAtSweepInPct = (uint8_t)jsonVal(body,"uvOffAtSweepInPct",cfg.uvOffAtSweepInPct); cfg.uvOnAtSweepOutPct = (uint8_t)jsonVal(body,"uvOnAtSweepOutPct",cfg.uvOnAtSweepOutPct);
  cfg.stopDisplayEnabled = jsonBool(body,"stopDisplayEnabled",cfg.stopDisplayEnabled); cfg.stopDisplayPeriodMs = jsonVal(body,"stopDisplayPeriodMs",cfg.stopDisplayPeriodMs); cfg.stopDisplayLedBrightnessPct = (uint8_t)jsonVal(body,"stopDisplayLedBrightnessPct",cfg.stopDisplayLedBrightnessPct); cfg.beaconDisplayFaultOnlyMode = jsonBool(body,"beaconDisplayFaultOnlyMode",cfg.beaconDisplayFaultOnlyMode);
  cfg.staEnabled = jsonBool(body,"staEnabled",cfg.staEnabled);
  jsonStr(body,"apSsid",cfg.apSsid,sizeof(cfg.apSsid)); jsonStr(body,"apPass",cfg.apPass,sizeof(cfg.apPass)); jsonStr(body,"staSsid",cfg.staSsid,sizeof(cfg.staSsid)); jsonStr(body,"staPass",cfg.staPass,sizeof(cfg.staPass));
  saveConfig(prefs,cfg); server.send(200,"application/json","{\"ok\":true}");
}

void setup(){
  loadConfig(prefs,cfg);
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
  tcaWriteReg(REG_CONFIG, 0x00); tcaWriteReg(REG_POLARITY, 0x00); tcaWriteReg(REG_OUTPUT, 0x00);
  for(int i=1;i<=8;i++) pinMode(PIN_DI[i], INPUT_PULLUP);
  strip.begin(); strip.show(); beacon.begin(); beacon.show(); onboard.begin(); onboard.show();
  st.showName = showStateName(st.showState);
  goStoppedA("Boot complete"); setShowState(SHOW_IDLE_UV); refreshNextAdvanceEdge();

  WiFi.mode(WIFI_AP_STA);
  if(cfg.staEnabled && strlen(cfg.staSsid) > 0){
    WiFi.begin(cfg.staSsid, cfg.staPass);
    uint32_t start = millis();
    while((millis() - start) < 8000 && WiFi.status() != WL_CONNECTED){ delay(100); }
    if(WiFi.status() == WL_CONNECTED){ wifiStaConnected = true; wifiStaIp = WiFi.localIP().toString(); wifiModeName = "STA+AP"; }
  }
  WiFi.softAPConfig(apIP,apGW,apSN);
  WiFi.softAP(cfg.apSsid, cfg.apPass);
  if(!wifiStaConnected) wifiModeName = "AP";
  server.on("/", HTTP_GET, handleIndex); server.on("/api/state", HTTP_GET, handleState); server.on("/api/cmd", HTTP_GET, handleCmd); server.on("/api/inject", HTTP_POST, handleInject); server.on("/api/setup/get", HTTP_GET, handleSetupGet); server.on("/api/setup/set", HTTP_POST, handleSetupSet); server.begin();
}

void loop(){
  server.handleClient();
  updateInputs();
  tickPending();
  tickFaults();
  tickSafeApply();
  tickTurnout();
  ensureRelaySafety();
  tickShow();
  tickPixelRailSequencer();
  tickBeacon();
  composeRelaysToHardware();
}
