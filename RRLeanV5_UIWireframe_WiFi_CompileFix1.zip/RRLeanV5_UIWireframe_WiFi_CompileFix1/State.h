#pragma once
#include <Arduino.h>
#include "Config.h"

enum Mode : uint8_t { MODE_STOP=0, MODE_RUN=1, MODE_RETURN=2 };
enum LoopPhase : uint8_t {
  PHASE_STOPPED_A=0,
  PHASE_VISIBLE_TO_B_PRE_S1,
  PHASE_VISIBLE_TO_B_POST_S1,
  PHASE_VISIBLE_TO_B_POST_S2_SEEN,
  PHASE_DWELL_B,
  PHASE_HIDDEN_TO_A_PRE_S3,
  PHASE_HIDDEN_TO_A_POST_S3_SEEN,
  PHASE_HIDDEN_TO_A_FAST,
  PHASE_HIDDEN_TO_A_APPROACH_A,
  PHASE_DWELL_A,
  PHASE_STOPPED_B,
  PHASE_FAULT_STOP
};
enum SensorId : uint8_t { SENSOR_NONE=0, SENSOR_S1=1, SENSOR_S2=2, SENSOR_S3=3, SENSOR_S4=4, SENSOR_DI7=7 };
enum ShowState : uint8_t { SHOW_IDLE_UV=0, SHOW_SWEEP_IN, SHOW_DWELL_LIT, SHOW_SWEEP_OUT, SHOW_STOP_DISPLAY, SHOW_FAULT_OVERRIDE };
enum SafeApplyStage : uint8_t { APPLY_IDLE=0, APPLY_CUT_POWER, APPLY_SET_SELECTOR, APPLY_SET_POLARITY, APPLY_ENABLE_POWER };

struct LiveInputs { bool s1=false, s2=false, s3=false, s4=false, di6=false, di7=false; };
struct RelayState { bool ch1=false, ch2=false, ch3=false, ch4=false, ch5=false, ch6=false, ch7=false, ch8=true; };
struct DebouncedInput {
  bool raw=false, stable=false;
  uint32_t rawChangedAt=0, stableChangedAt=0;
  bool seenEdge=false, clearEdge=false;
  uint32_t activeSince=0;
};
struct PendingAction {
  bool active=false;
  uint32_t dueAt=0;
  uint8_t kind=0;
  SensorId sensor=SENSOR_NONE;
  const char* note="";
};
struct MotionTarget {
  bool powerOn=false;
  bool hi=false;
  bool reverse=false;
  bool trackVisible=true;
};

struct RuntimeState {
  Mode mode = MODE_STOP;
  LoopPhase phase = PHASE_STOPPED_A;
  ShowState showState = SHOW_IDLE_UV;
  SafeApplyStage applyStage = APPLY_IDLE;

  bool faultLatched=false;
  String faultCode="CLEAR";
  String expectedSensor="S1";
  String lastSensor="-";
  String route="VISIBLE";
  String direction="FWD";
  String speed="OFF";
  String loopState="STOPPED_A";
  String phaseNote="Boot";
  String showName="IDLE_UV";

  LiveInputs in;
  RelayState rel;
  DebouncedInput dbS1, dbS2, dbS3, dbS4, dbDI6, dbDI7;

  bool inCaveHazardZone=false;
  bool firstProgressSeen=false;
  bool manualStop=true;
  bool arrivalSweepDoneThisCycle=false;
  bool departureSweepDoneThisCycle=false;
  bool stopDisplayPhaseIsLed=false;
  bool faultCutsCavePower=false;
  bool awaitingClearForLastSeen=false;
  bool di7HoldHandled=false;

  bool virtualS1=false, virtualS2=false, virtualS3=false, virtualS4=false, virtualDI6=false, virtualDI7=false;
  bool useVirtualInputs=false;

  PendingAction pendingStop, pendingSlow, pendingDwell;

  MotionTarget desiredMotion;
  MotionTarget appliedMotion;
  bool turnoutTargetVisible=true;
  bool turnoutPulseActive=false;
  uint32_t turnoutPulseUntil=0;
  uint32_t lastTurnoutPulseAt=0;

  uint32_t applyStageStartedAt=0;
  uint32_t applyDeadlineAt=0;
  uint32_t lastSensorEdgeAt=0;
  uint32_t lastExpectedArmAt=0;
  uint32_t modeChangedAt=0;
  uint32_t phaseChangedAt=0;
  uint32_t faultAt=0;
  uint32_t showStartedAt=0;
  uint32_t stopDisplayPhaseStartedAt=0;
  uint32_t di7PressedAt=0;
  uint32_t pixelCutAt=0;
  uint32_t pixelPowerOnReadyAt=0;

  uint32_t seenCountS1=0, seenCountS2=0, seenCountS3=0, seenCountS4=0;
  String nextAdvanceEdge="S1 SEEN";
};

static inline const char* modeStr(Mode m){ switch(m){case MODE_RUN:return "RUN"; case MODE_RETURN:return "RETURN"; default:return "STOP";} }
static inline const char* sensorName(SensorId s){ switch(s){case SENSOR_S1:return "S1"; case SENSOR_S2:return "S2"; case SENSOR_S3:return "S3"; case SENSOR_S4:return "S4"; case SENSOR_DI7:return "DI7"; default:return "-";} }
static inline const char* phaseName(LoopPhase p){
  switch(p){
    case PHASE_STOPPED_A:return "STOPPED_A";
    case PHASE_VISIBLE_TO_B_PRE_S1:return "VISIBLE_TO_B_PRE_S1";
    case PHASE_VISIBLE_TO_B_POST_S1:return "VISIBLE_TO_B_POST_S1";
    case PHASE_VISIBLE_TO_B_POST_S2_SEEN:return "VISIBLE_TO_B_POST_S2_SEEN";
    case PHASE_DWELL_B:return "DWELL_B";
    case PHASE_HIDDEN_TO_A_PRE_S3:return "HIDDEN_TO_A_PRE_S3";
    case PHASE_HIDDEN_TO_A_POST_S3_SEEN:return "HIDDEN_TO_A_POST_S3_SEEN";
    case PHASE_HIDDEN_TO_A_FAST:return "HIDDEN_TO_A_FAST";
    case PHASE_HIDDEN_TO_A_APPROACH_A:return "HIDDEN_TO_A_APPROACH_A";
    case PHASE_DWELL_A:return "DWELL_A";
    case PHASE_STOPPED_B:return "STOPPED_B";
    case PHASE_FAULT_STOP:return "FAULT_STOP";
    default:return "?";
  }
}
static inline const char* showStateName(ShowState s){ switch(s){ case SHOW_IDLE_UV:return "IDLE_UV"; case SHOW_SWEEP_IN:return "SWEEP_IN"; case SHOW_DWELL_LIT:return "DWELL_LIT"; case SHOW_SWEEP_OUT:return "SWEEP_OUT"; case SHOW_STOP_DISPLAY:return "STOP_DISPLAY"; case SHOW_FAULT_OVERRIDE:return "FAULT_OVERRIDE"; default:return "?";} }
