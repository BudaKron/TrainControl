#pragma once
#include <Arduino.h>

static const char HTML_INDEX[] PROGMEM = R"HTML(
<!doctype html><html><head>
<meta name='viewport' content='width=device-width,initial-scale=1'>
<title>RRLean V4 Bench Ready</title>
<style>
:root{--bg:#020508;--panel:#060b10;--line:#57bfff;--text:#d9f3ff;--muted:#7fb5d1;--dim:#0b1721;--good:#4fe28c;--warn:#ffd15c;--bad:#ff667f;--accent:#63c8ff}
*{box-sizing:border-box} html,body{margin:0;background:var(--bg);color:var(--text);font-family:Consolas,Menlo,monospace}
body{min-height:100vh}
#top{padding:14px 14px 190px;max-width:1500px;margin:0 auto} #bottom{position:fixed;left:0;right:0;bottom:0;background:#03080d;border-top:2px solid var(--line);padding:10px 12px;display:flex;flex-direction:column;gap:10px;min-height:180px}
.header{display:flex;justify-content:space-between;align-items:center;border:2px solid var(--line);padding:14px 16px;background:#02070c;box-shadow:0 0 0 1px rgba(87,191,255,.12) inset}.headTitle{font-size:22px;letter-spacing:.06em}.headStatus{font-size:18px}
.tabs{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}.tab{border:2px solid var(--line);background:transparent;color:var(--text);padding:10px 14px;cursor:pointer;min-width:120px;text-align:center}.tab.active{background:#07131d;box-shadow:0 0 0 1px var(--line) inset;font-weight:700}
.panel{display:none}.panel.active{display:block}
.grid3{display:grid;grid-template-columns:1.2fr 1.2fr 1fr;gap:12px}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}.grid4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}@media(max-width:1100px){.grid3,.grid4,.grid2{grid-template-columns:1fr 1fr}}@media(max-width:760px){.grid3,.grid4,.grid2{grid-template-columns:1fr}}
.card{background:var(--panel);border:2px solid rgba(87,191,255,.75);padding:14px;min-height:100px}.card h3{margin:0 0 10px;font-size:16px;letter-spacing:.05em;color:var(--accent)}.sub{color:var(--muted);font-size:12px;line-height:1.4}
.row{display:grid;grid-template-columns:1fr 130px;gap:10px;align-items:center;padding:5px 0;border-bottom:1px solid rgba(87,191,255,.14)}.row:last-child{border-bottom:none}.row label{font-size:13px;color:var(--text)}
input[type=number],input[type=text],input[type=password]{width:100%;background:#01050a;color:var(--text);border:1px solid var(--line);padding:8px 9px;font-family:inherit}input[type=checkbox]{transform:scale(1.2)}
.statBig{font-size:28px;font-weight:700}.statMid{font-size:20px}.mono{word-break:break-word}.lineList{display:grid;gap:7px}.line{display:flex;justify-content:space-between;gap:12px;border-bottom:1px solid rgba(87,191,255,.12);padding-bottom:6px}
button{border:2px solid var(--line);background:#05111a;color:var(--text);padding:12px 10px;font-family:inherit;font-size:16px;font-weight:700;cursor:pointer}button:hover{background:#0a1b29}.run{border-color:var(--good);color:var(--good)}.stop{border-color:var(--bad);color:var(--bad)}.ret{border-color:var(--warn);color:var(--warn)}.clear{border-color:var(--accent);color:var(--accent)}.small{padding:10px 8px;font-size:14px}.btnGrid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.injGrid{display:grid;grid-template-columns:repeat(6,1fr);gap:10px}@media(max-width:760px){.btnGrid,.injGrid{grid-template-columns:1fr 1fr}}
.footerStatus{display:grid;grid-template-columns:2fr 1fr 1fr 1fr 1fr;gap:10px}@media(max-width:900px){.footerStatus{grid-template-columns:1fr 1fr}}
.badge{display:inline-block;padding:5px 8px;border:1px solid var(--line);margin-right:8px;font-size:12px}.savebar{display:flex;justify-content:flex-end;gap:10px;margin-top:12px}.mutebox{opacity:.88}
</style></head><body>
<div id='top'>
  <div class='header'>
    <div class='headTitle'>RRLean Control Interface</div>
    <div class='headStatus' id='hdrStatus'>STATUS: STOP / CLEAR</div>
  </div>

  <div class='tabs'>
    <button class='tab active' data-tab='main' onclick='showTab("main",this)'>MAIN</button>
    <button class='tab' data-tab='timing' onclick='showTab("timing",this)'>TIMING</button>
    <button class='tab' data-tab='cave' onclick='showTab("cave",this)'>CAVE</button>
    <button class='tab' data-tab='display' onclick='showTab("display",this)'>DISPLAY</button>
    <button class='tab' data-tab='settings' onclick='showTab("settings",this)'>SETTINGS</button>
  </div>

  <section id='tab-main' class='panel active'>
    <div class='grid3'>
      <div class='card'>
        <h3>SYSTEM MODE</h3>
        <div class='btnGrid'>
          <button class='run' onclick="cmd('run')">RUN</button>
          <button class='stop' onclick="cmd('stop')">STOP</button>
          <button class='ret' onclick="cmd('return')">RETURN</button>
          <button class='clear' onclick="cmd('clearfault')">CLEAR FAULT</button>
        </div>
        <div style='height:12px'></div>
        <div class='lineList'>
          <div class='line'><span>Expected Sensor</span><span id='mainExpected'>S1</span></div>
          <div class='line'><span>Last Sensor</span><span id='mainLast'>-</span></div>
          <div class='line'><span>Next DI6 Action</span><span id='mainAdvance'>S1 SEEN</span></div>
          <div class='line'><span>Hazard Zone</span><span id='mainHazard'>false</span></div>
        </div>
      </div>
      <div class='card'>
        <h3>FAULT / MOTION STATUS</h3>
        <div class='statBig' id='mainFault'>CLEAR</div>
        <div class='sub mono' id='mainPhase'>STOPPED_A</div>
        <div style='height:12px'></div>
        <div class='lineList'>
          <div class='line'><span>Route</span><span id='mainRoute'>VISIBLE</span></div>
          <div class='line'><span>Direction</span><span id='mainDir'>FWD</span></div>
          <div class='line'><span>Speed</span><span id='mainSpeed'>OFF</span></div>
          <div class='line'><span>Apply Stage</span><span id='mainApply'>0</span></div>
          <div class='line'><span>Show State</span><span id='mainShow'>IDLE_UV</span></div>
        </div>
      </div>
      <div class='card'>
        <h3>REMOTE VISIBILITY</h3>
        <div class='statMid' id='mainBeacon'>BEACON: NORMAL</div>
        <div style='height:12px'></div>
        <div class='lineList'>
          <div class='line'><span>Relay Bitmap</span><span id='mainRelays'>00000000</span></div>
          <div class='line'><span>Seen Counts</span><span id='mainCounts'>0 / 0 / 0 / 0</span></div>
          <div class='line'><span>AP Address</span><span id='mainApIp'>192.168.4.1</span></div>
          <div class='line'><span>Wi-Fi Mode</span><span id='mainWifiMode'>AP</span></div>
          <div class='line'><span>Station IP</span><span id='mainStaIp'>-</span></div>
        </div>
      </div>
    </div>
    <div style='height:12px'></div>
    <div class='card'>
      <h3>TEST INPUTS</h3>
      <div class='injGrid'>
        <button class='small clear' onclick="pulse('s1')">PULSE S1</button>
        <button class='small clear' onclick="pulse('s2')">PULSE S2</button>
        <button class='small clear' onclick="pulse('s3')">PULSE S3</button>
        <button class='small clear' onclick="pulse('s4')">PULSE S4</button>
        <button class='small clear' onclick="cmd('advance')">ADVANCE DI6</button>
        <button class='small clear' onclick="pulse('di7')">PULSE DI7</button>
      </div>
    </div>
  </section>

  <section id='tab-timing' class='panel'>
    <div class='grid4'>
      <div class='card'><h3>S1 VISIBLE A</h3><div class='sub'>Launch confirmation</div><div class='row'><label>Seen Debounce</label><input id='s1_seenDebounceMs' type='number'></div><div class='row'><label>Clear Debounce</label><input id='s1_clearDebounceMs' type='number'></div><div class='row'><label>Stop After Seen</label><input id='s1_stopAfterSeenMs' type='number'></div><div class='row'><label>Stop After Clear</label><input id='s1_stopAfterClearMs' type='number'></div><div class='row'><label>Slow After Seen</label><input id='s1_slowAfterSeenMs' type='number'></div><div class='row'><label>Slow After Clear</label><input id='s1_slowAfterClearMs' type='number'></div></div>
      <div class='card'><h3>S2 CAVE ENTRY</h3><div class='sub'>Stop trigger and hazard start</div><div class='row'><label>Seen Debounce</label><input id='s2_seenDebounceMs' type='number'></div><div class='row'><label>Clear Debounce</label><input id='s2_clearDebounceMs' type='number'></div><div class='row'><label>Stop After Seen</label><input id='s2_stopAfterSeenMs' type='number'></div><div class='row'><label>Stop After Clear</label><input id='s2_stopAfterClearMs' type='number'></div><div class='row'><label>Slow After Seen</label><input id='s2_slowAfterSeenMs' type='number'></div><div class='row'><label>Slow After Clear</label><input id='s2_slowAfterClearMs' type='number'></div></div>
      <div class='card'><h3>S3 HIDDEN EXIT</h3><div class='sub'>Fast enable, hazard end on clear</div><div class='row'><label>Seen Debounce</label><input id='s3_seenDebounceMs' type='number'></div><div class='row'><label>Clear Debounce</label><input id='s3_clearDebounceMs' type='number'></div><div class='row'><label>Stop After Seen</label><input id='s3_stopAfterSeenMs' type='number'></div><div class='row'><label>Stop After Clear</label><input id='s3_stopAfterClearMs' type='number'></div><div class='row'><label>Slow After Seen</label><input id='s3_slowAfterSeenMs' type='number'></div><div class='row'><label>Slow After Clear</label><input id='s3_slowAfterClearMs' type='number'></div></div>
      <div class='card'><h3>S4 HIDDEN A</h3><div class='sub'>Slow and stop at A</div><div class='row'><label>Seen Debounce</label><input id='s4_seenDebounceMs' type='number'></div><div class='row'><label>Clear Debounce</label><input id='s4_clearDebounceMs' type='number'></div><div class='row'><label>Stop After Seen</label><input id='s4_stopAfterSeenMs' type='number'></div><div class='row'><label>Stop After Clear</label><input id='s4_stopAfterClearMs' type='number'></div><div class='row'><label>Slow After Seen</label><input id='s4_slowAfterSeenMs' type='number'></div><div class='row'><label>Slow After Clear</label><input id='s4_slowAfterClearMs' type='number'></div></div>
    </div>
    <div style='height:12px'></div>
    <div class='grid2'>
      <div class='card'><h3>SAFETY TIMERS</h3><div class='row'><label>Min Between Sensors</label><input id='minBetweenSensorsMs' type='number'></div><div class='row'><label>Sensor Stuck Timeout</label><input id='sensorStuckTimeoutMs' type='number'></div><div class='row'><label>Start Move Timeout</label><input id='startMoveTimeoutMs' type='number'></div><div class='row'><label>Fault Restart Lockout</label><input id='faultRestartLockoutMs' type='number'></div><div class='row'><label>Timeout To S1</label><input id='timeoutToS1Ms' type='number'></div><div class='row'><label>Timeout To S2</label><input id='timeoutToS2Ms' type='number'></div><div class='row'><label>Timeout To S3</label><input id='timeoutToS3Ms' type='number'></div><div class='row'><label>Timeout To S4</label><input id='timeoutToS4Ms' type='number'></div></div>
      <div class='card'><h3>MOTION / APPLY</h3><div class='row'><label>Interlock Deadtime</label><input id='interlockDeadtimeMs' type='number'></div><div class='row'><label>Selector Settle</label><input id='selectorSettleMs' type='number'></div><div class='row'><label>Polarity Settle</label><input id='polaritySettleMs' type='number'></div><div class='row'><label>Safe Apply Timeout</label><input id='safeApplyTimeoutMs' type='number'></div><div class='row'><label>Turnout Pulse</label><input id='turnoutPulseMs' type='number'></div><div class='row'><label>Turnout Rearm</label><input id='turnoutInterpulseMs' type='number'></div><div class='row'><label>Stop To Run Cooldown</label><input id='stopToRunCooldownMs' type='number'></div><div class='row'><label>Dwell A</label><input id='dwellA_ms' type='number'></div><div class='row'><label>Dwell B</label><input id='dwellB_ms' type='number'></div><div class='row'><label>S2 Coast Compensation</label><input id='s2CoastCompMs' type='number'></div><div class='row'><label>S4 Coast Compensation</label><input id='s4CoastCompMs' type='number'></div></div>
    </div>
  </section>

  <section id='tab-cave' class='panel'>
    <div class='grid2'>
      <div class='card'><h3>TUNNEL / CAVE PIXELS</h3><div class='sub'>GPIO21 shared rail. Tunnel 0-15. Cave 16-50.</div><div class='row'><label>Pixel Power On Settle</label><input id='pixelPowerOnSettleMs' type='number'></div><div class='row'><label>Black Before Power Cut</label><input id='pixelBlackBeforePowerCutMs' type='number'></div><div class='row'><label>Sweep In ms</label><input id='sweepInMs' type='number'></div><div class='row'><label>Sweep In Curve</label><input id='sweepInCurve' type='number'></div><div class='row'><label>Sweep Out ms</label><input id='sweepOutMs' type='number'></div><div class='row'><label>Sweep Out Curve</label><input id='sweepOutCurve' type='number'></div></div>
      <div class='card'><h3>CAVE LOOK</h3><div class='row'><label>Cave Fade In</label><input id='caveFadeInMs' type='number'></div><div class='row'><label>Cave Fade Out</label><input id='caveFadeOutMs' type='number'></div><div class='row'><label>Cave Hold Brightness %</label><input id='caveHoldBrightnessPct' type='number'></div><div class='row'><label>UV Off At Sweep In %</label><input id='uvOffAtSweepInPct' type='number'></div><div class='row'><label>UV On At Sweep Out %</label><input id='uvOnAtSweepOutPct' type='number'></div><div class='sub'>One sweep in and one sweep out per train arrival cycle. Tunnel stays dark during dwell.</div></div>
    </div>
  </section>

  <section id='tab-display' class='panel'>
    <div class='grid2'>
      <div class='card'><h3>STOP DISPLAY</h3><div class='row'><label>Stop Display Enabled</label><input id='stopDisplayEnabled' type='checkbox'></div><div class='row'><label>Stop Display Period</label><input id='stopDisplayPeriodMs' type='number'></div><div class='row'><label>Stop Display LED %</label><input id='stopDisplayLedBrightnessPct' type='number'></div><div class='sub'>STOP mode alternates UV-only and FullSpec cave-only. Power/control faults fall back here from UV phase. Motion-stuck cave faults go fully dark.</div></div>
      <div class='card'><h3>BEACON / REMOTE STATUS</h3><div class='row'><label>Beacon Fault Only</label><input id='beaconDisplayFaultOnlyMode' type='checkbox'></div><div class='sub'>GPIO47. Normal: RUN green, RETURN yellow, STOP red, FAULT flashing red. Fault-only mode disables healthy output and only shows red on fault.</div></div>
    </div>
  </section>

  <section id='tab-settings' class='panel'>
    <div class='grid2'>
      <div class='card'>
        <h3>AP ACCESS POINT</h3>
        <div class='row'><label>AP SSID</label><input id='apSsid' type='text' maxlength='32'></div>
        <div class='row'><label>AP Password</label><input id='apPass' type='password' maxlength='64'></div>
        <div class='lineList'><div class='line'><span>AP IP</span><span id='setApIp'>192.168.4.1</span></div><div class='line'><span>Current Mode</span><span id='setWifiMode'>AP</span></div></div>
      </div>
      <div class='card'>
        <h3>STATION CONNECTION</h3>
        <div class='row'><label>Enable Station</label><input id='staEnabled' type='checkbox'></div>
        <div class='row'><label>STA SSID</label><input id='staSsid' type='text' maxlength='32'></div>
        <div class='row'><label>STA Password</label><input id='staPass' type='password' maxlength='64'></div>
        <div class='sub'>On boot the controller will try Station first when enabled. If it does not connect in time, it falls back to AP so the local interface is still available.</div>
      </div>
    </div>
    <div class='savebar'>
      <button class='clear' onclick='saveSetup()'>SAVE SETTINGS</button>
    </div>
  </section>
</div>

<div id='bottom'>
  <div class='footerStatus'>
    <div class='card'><div class='sub'>SYSTEM STATUS</div><div class='statMid' id='statusMain'>STOP / CLEAR</div><div class='sub mono' id='statusSub'>Expect S1 • VISIBLE • FWD • OFF • STOPPED_A</div></div>
    <div class='card'><div class='sub'>SHOW</div><div class='statMid' id='diagShow'>IDLE_UV</div></div>
    <div class='card'><div class='sub'>FAULT</div><div class='statMid' id='diagFault'>CLEAR</div></div>
    <div class='card'><div class='sub'>BEACON</div><div class='statMid' id='diagBeacon'>NORMAL</div></div>
    <div class='card'><div class='sub'>INPUT COUNTS</div><div class='statMid' id='diagCounts'>0/0/0/0</div></div>
  </div>
</div>

<script>
const ids=['s1_seenDebounceMs','s1_clearDebounceMs','s1_stopAfterSeenMs','s1_stopAfterClearMs','s1_slowAfterSeenMs','s1_slowAfterClearMs','s2_seenDebounceMs','s2_clearDebounceMs','s2_stopAfterSeenMs','s2_stopAfterClearMs','s2_slowAfterSeenMs','s2_slowAfterClearMs','s3_seenDebounceMs','s3_clearDebounceMs','s3_stopAfterSeenMs','s3_stopAfterClearMs','s3_slowAfterSeenMs','s3_slowAfterClearMs','s4_seenDebounceMs','s4_clearDebounceMs','s4_stopAfterSeenMs','s4_stopAfterClearMs','s4_slowAfterSeenMs','s4_slowAfterClearMs','minBetweenSensorsMs','sensorStuckTimeoutMs','timeoutToS1Ms','timeoutToS2Ms','timeoutToS3Ms','timeoutToS4Ms','startMoveTimeoutMs','faultRestartLockoutMs','interlockDeadtimeMs','selectorSettleMs','polaritySettleMs','safeApplyTimeoutMs','turnoutPulseMs','turnoutInterpulseMs','stopToRunCooldownMs','dwellA_ms','dwellB_ms','s2CoastCompMs','s4CoastCompMs','pixelPowerOnSettleMs','pixelBlackBeforePowerCutMs','sweepInMs','sweepInCurve','sweepOutMs','sweepOutCurve','caveFadeInMs','caveFadeOutMs','caveHoldBrightnessPct','uvOffAtSweepInPct','uvOnAtSweepOutPct','stopDisplayPeriodMs','stopDisplayLedBrightnessPct','apSsid','apPass','staSsid','staPass'];
const boolIds=['stopDisplayEnabled','beaconDisplayFaultOnlyMode','staEnabled'];
function showTab(name,el){ document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active')); document.getElementById('tab-'+name).classList.add('active'); document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active')); el.classList.add('active'); }
async function loadSetup(){ const r=await fetch('/api/setup/get'); const j=await r.json(); ids.forEach(id=>{ const e=document.getElementById(id); if(!e) return; e.value=(j[id]??''); }); boolIds.forEach(id=>{ const e=document.getElementById(id); if(e) e.checked=!!j[id]; }); }
async function saveSetup(){ const body={}; ids.forEach(id=>{ const e=document.getElementById(id); if(!e) return; body[id]=(e.type==='number')?Number(e.value||0):String(e.value||'');}); boolIds.forEach(id=>{ const e=document.getElementById(id); if(e) body[id]=e.checked;}); await fetch('/api/setup/set',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}); }
function relayBits(r){ return ['ch1','ch2','ch3','ch4','ch5','ch6','ch7','ch8'].map(k=>r[k]?'1':'0').join(''); }
async function poll(){ try{ const r=await fetch('/api/state'); const j=await r.json(); document.getElementById('hdrStatus').textContent=`STATUS: ${j.mode} / ${j.faultCode}`; document.getElementById('statusMain').textContent=`${j.mode} / ${j.faultCode}`; document.getElementById('statusSub').textContent=`Expect ${j.expectedSensor} • ${j.route} • ${j.direction} • ${j.speed} • ${j.loopState}`; document.getElementById('mainExpected').textContent=j.expectedSensor; document.getElementById('mainLast').textContent=j.lastSensor; document.getElementById('mainAdvance').textContent=j.nextAdvanceEdge; document.getElementById('mainHazard').textContent=String(j.inCaveHazardZone); document.getElementById('mainFault').textContent=j.faultCode; document.getElementById('mainPhase').textContent=j.phaseNote; document.getElementById('mainRoute').textContent=j.route; document.getElementById('mainDir').textContent=j.direction; document.getElementById('mainSpeed').textContent=j.speed; document.getElementById('mainApply').textContent=j.applyStageText||j.applyStage; document.getElementById('mainShow').textContent=j.showName; document.getElementById('mainBeacon').textContent='BEACON: '+j.beaconMode; document.getElementById('mainRelays').textContent=relayBits(j.relays); document.getElementById('mainCounts').textContent=`${j.counters.s1} / ${j.counters.s2} / ${j.counters.s3} / ${j.counters.s4}`; document.getElementById('mainApIp').textContent=j.apIp||j.ip; document.getElementById('mainWifiMode').textContent=j.wifiMode; document.getElementById('mainStaIp').textContent=j.staIp||'-'; document.getElementById('diagShow').textContent=j.showName; document.getElementById('diagFault').textContent=j.faultCode; document.getElementById('diagBeacon').textContent=j.beaconMode; document.getElementById('diagCounts').textContent=`${j.counters.s1}/${j.counters.s2}/${j.counters.s3}/${j.counters.s4}`; document.getElementById('setApIp').textContent=j.apIp||j.ip; document.getElementById('setWifiMode').textContent=j.wifiMode; }catch(e){} }
async function cmd(m){ await fetch('/api/cmd?mode='+encodeURIComponent(m)); }
async function pulse(name){ const on={}; on[name]=true; await fetch('/api/inject',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(on)}); setTimeout(()=>fetch('/api/inject',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({[name]:false})}),180); }
loadSetup(); poll(); setInterval(poll,500);
</script></body></html>)HTML";
